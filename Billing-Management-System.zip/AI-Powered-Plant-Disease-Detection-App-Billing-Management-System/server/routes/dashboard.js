const express = require('express');
const router = express.Router();
const Invoice = require('../models/Invoice');
const Customer = require('../models/Customer');
const Product = require('../models/Product');

// Get dashboard stats
router.get('/stats', async (req, res) => {
  try {
    const [totalSales, totalInvoices, totalCustomers, totalProducts, pendingPayments] = await Promise.all([
      Invoice.aggregate([
        { $match: { status: 'paid' } },
        { $group: { _id: null, total: { $sum: '$total' } } }
      ]),
      Invoice.countDocuments(),
      Customer.countDocuments(),
      Product.countDocuments(),
      Invoice.aggregate([
        { $match: { status: { $in: ['unpaid', 'partial'] } } },
        { $group: { _id: null, total: { $sum: '$total' } } }
      ])
    ]);

    res.json({
      totalSales: totalSales[0]?.total || 0,
      totalInvoices,
      totalCustomers,
      totalProducts,
      pendingPayments: pendingPayments[0]?.total || 0
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get sales chart data
router.get('/sales-chart', async (req, res) => {
  try {
    const salesData = await Invoice.aggregate([
      {
        $match: {
          status: 'paid',
          date: { $gte: new Date(new Date().getFullYear(), 0, 1) }
        }
      },
      {
        $group: {
          _id: { $month: '$date' },
          sales: { $sum: '$total' },
          orders: { $sum: 1 }
        }
      },
      {
        $sort: { _id: 1 }
      }
    ]);

    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const formattedData = months.map((month, index) => {
      const data = salesData.find(item => item._id === index + 1);
      return {
        month,
        sales: data?.sales || 0,
        orders: data?.orders || 0
      };
    });

    res.json(formattedData);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get top products
router.get('/top-products', async (req, res) => {
  try {
    const topProducts = await Invoice.aggregate([
      { $unwind: '$items' },
      {
        $group: {
          _id: '$items.productName',
          value: { $sum: '$items.quantity' },
          revenue: { $sum: '$items.total' }
        }
      },
      { $sort: { value: -1 } },
      { $limit: 5 },
      {
        $project: {
          name: '$_id',
          value: 1,
          revenue: 1,
          _id: 0
        }
      }
    ]);

    res.json(topProducts);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;