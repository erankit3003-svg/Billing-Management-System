const express = require('express');
const router = express.Router();
const Invoice = require('../models/Invoice');
const Customer = require('../models/Customer');

// Get report data
router.get('/', async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const dateFilter = {};
    
    if (startDate && endDate) {
      dateFilter.date = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }

    const [salesByMonth, salesByProduct, customerStats, revenueGrowth] = await Promise.all([
      // Monthly sales
      Invoice.aggregate([
        { $match: { ...dateFilter, status: 'paid' } },
        {
          $group: {
            _id: { $month: '$date' },
            sales: { $sum: '$total' },
            orders: { $sum: 1 }
          }
        },
        { $sort: { _id: 1 } }
      ]),
      
      // Sales by product
      Invoice.aggregate([
        { $match: dateFilter },
        { $unwind: '$items' },
        {
          $group: {
            _id: '$items.productName',
            quantity: { $sum: '$items.quantity' },
            revenue: { $sum: '$items.total' }
          }
        },
        { $sort: { quantity: -1 } },
        { $limit: 10 },
        {
          $project: {
            name: '$_id',
            quantity: 1,
            revenue: 1,
            _id: 0
          }
        }
      ]),
      
      // Customer statistics
      Invoice.aggregate([
        { $match: dateFilter },
        {
          $group: {
            _id: '$customerId',
            totalSpent: { $sum: '$total' },
            invoiceCount: { $sum: 1 }
          }
        },
        { $sort: { totalSpent: -1 } },
        { $limit: 10 },
        {
          $lookup: {
            from: 'customers',
            localField: '_id',
            foreignField: '_id',
            as: 'customer'
          }
        },
        { $unwind: '$customer' },
        {
          $project: {
            name: '$customer.name',
            email: '$customer.email',
            totalSpent: 1,
            invoiceCount: 1,
            _id: 0
          }
        }
      ]),
      
      // Revenue growth
      Invoice.aggregate([
        { $match: { ...dateFilter, status: 'paid' } },
        {
          $group: {
            _id: { $month: '$date' },
            revenue: { $sum: '$total' }
          }
        },
        { $sort: { _id: 1 } }
      ])
    ]);

    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    
    const formattedSalesByMonth = months.map((month, index) => {
      const data = salesByMonth.find(item => item._id === index + 1);
      return {
        month,
        sales: data?.sales || 0,
        orders: data?.orders || 0
      };
    });

    const formattedRevenueGrowth = months.map((month, index) => {
      const data = revenueGrowth.find(item => item._id === index + 1);
      return {
        month,
        revenue: data?.revenue || 0
      };
    });

    res.json({
      salesByMonth: formattedSalesByMonth,
      salesByProduct,
      customerStats,
      revenueGrowth: formattedRevenueGrowth
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Export to PDF
router.get('/export/pdf', async (req, res) => {
  try {
    // PDF export logic would go here
    // For now, return a placeholder response
    res.json({ message: 'PDF export functionality would be implemented here' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Export to Excel
router.get('/export/excel', async (req, res) => {
  try {
    // Excel export logic would go here
    // For now, return a placeholder response
    res.json({ message: 'Excel export functionality would be implemented here' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;