import jsPDF from 'jspdf';
import 'jspdf-autotable';

interface Invoice {
  invoiceNumber: string;
  date: string;
  dueDate: string;
  status: string;
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  notes: string;
  customer: {
    name: string;
    email: string;
    phone: string;
    address: string;
    gstNumber: string;
  };
  items: Array<{
    productName: string;
    quantity: number;
    price: number;
    total: number;
  }>;
}

export const generateInvoicePDF = (invoice: Invoice) => {
  const doc = new jsPDF();
  
  // Company header
  doc.setFontSize(20);
  doc.setTextColor(40);
  doc.text('INVOICE', 20, 30);
  
  doc.setFontSize(12);
  doc.setTextColor(100);
  doc.text('Invoice Management System', 20, 40);
  
  // Invoice details
  doc.setFontSize(10);
  doc.setTextColor(40);
  doc.text(`Invoice Number: ${invoice.invoiceNumber}`, 140, 30);
  doc.text(`Date: ${new Date(invoice.date).toLocaleDateString()}`, 140, 40);
  doc.text(`Due Date: ${new Date(invoice.dueDate).toLocaleDateString()}`, 140, 50);
  doc.text(`Status: ${invoice.status.toUpperCase()}`, 140, 60);
  
  // Customer details
  doc.setFontSize(12);
  doc.setTextColor(40);
  doc.text('Bill To:', 20, 70);
  
  doc.setFontSize(10);
  doc.text(invoice.customer.name, 20, 80);
  doc.text(invoice.customer.email, 20, 90);
  doc.text(invoice.customer.phone, 20, 100);
  
  if (invoice.customer.address) {
    const addressLines = doc.splitTextToSize(invoice.customer.address, 80);
    doc.text(addressLines, 20, 110);
  }
  
  if (invoice.customer.gstNumber) {
    doc.text(`GST: ${invoice.customer.gstNumber}`, 20, 130);
  }
  
  // Items table
  const tableData = invoice.items.map(item => [
    item.productName,
    item.quantity.toString(),
    `$${item.price.toFixed(2)}`,
    `$${item.total.toFixed(2)}`
  ]);
  
  (doc as any).autoTable({
    head: [['Item', 'Qty', 'Price', 'Total']],
    body: tableData,
    startY: 150,
    theme: 'grid',
    headStyles: {
      fillColor: [59, 130, 246],
      textColor: 255,
      fontSize: 10,
      fontStyle: 'bold'
    },
    bodyStyles: {
      fontSize: 9,
      textColor: 40
    },
    columnStyles: {
      0: { cellWidth: 80 },
      1: { cellWidth: 20, halign: 'center' },
      2: { cellWidth: 30, halign: 'right' },
      3: { cellWidth: 30, halign: 'right' }
    }
  });
  
  // Totals
  const finalY = (doc as any).lastAutoTable.finalY + 20;
  
  doc.setFontSize(10);
  doc.text('Subtotal:', 140, finalY);
  doc.text(`$${invoice.subtotal.toFixed(2)}`, 180, finalY);
  
  doc.text('Tax:', 140, finalY + 10);
  doc.text(`$${invoice.tax.toFixed(2)}`, 180, finalY + 10);
  
  if (invoice.discount > 0) {
    doc.text('Discount:', 140, finalY + 20);
    doc.text(`-$${invoice.discount.toFixed(2)}`, 180, finalY + 20);
  }
  
  // Total
  doc.setFontSize(12);
  doc.setFont(undefined, 'bold');
  const totalY = invoice.discount > 0 ? finalY + 35 : finalY + 25;
  doc.text('Total:', 140, totalY);
  doc.text(`$${invoice.total.toFixed(2)}`, 180, totalY);
  
  // Notes
  if (invoice.notes) {
    doc.setFontSize(10);
    doc.setFont(undefined, 'normal');
    doc.text('Notes:', 20, totalY + 20);
    const notesLines = doc.splitTextToSize(invoice.notes, 170);
    doc.text(notesLines, 20, totalY + 30);
  }
  
  // Footer
  doc.setFontSize(8);
  doc.setTextColor(100);
  doc.text('Thank you for your business!', 20, doc.internal.pageSize.height - 20);
  
  // Save the PDF
  doc.save(`invoice-${invoice.invoiceNumber}.pdf`);
};