import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Download, Edit, Mail, Printer } from 'lucide-react';
import { api } from '../services/api';
import { generateInvoicePDF } from '../utils/pdfGenerator';
import toast from 'react-hot-toast';

interface Invoice {
  id: string;
  invoiceNumber: string;
  date: string;
  dueDate: string;
  status: string;
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  notes: string;
  customer: {
    name: string;
    email: string;
    phone: string;
    address: string;
    gstNumber: string;
  };
  items: Array<{
    productName: string;
    quantity: number;
    price: number;
    total: number;
  }>;
}

export default function InvoiceDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchInvoice(id);
    }
  }, [id]);

  const fetchInvoice = async (invoiceId: string) => {
    try {
      const response = await api.get(`/invoices/${invoiceId}`);
      setInvoice(response.data);
      setLoading(false);
    } catch (error) {
      toast.error('Failed to fetch invoice');
      setLoading(false);
    }
  };

  const handleDownloadPDF = () => {
    if (invoice) {
      generateInvoicePDF(invoice);
      toast.success('PDF downloaded successfully');
    }
  };

  const handleSendEmail = async () => {
    try {
      await api.post(`/invoices/${id}/send-email`);
      toast.success('Invoice sent successfully');
    } catch (error) {
      toast.error('Failed to send invoice');
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'unpaid':
        return 'bg-red-100 text-red-800';
      case 'partial':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (!invoice) {
    return (
      <div className="text-center py-12">
        <h3 className="text-lg font-medium text-gray-900">Invoice not found</h3>
        <Link to="/invoices" className="btn btn-primary btn-md mt-4">
          Back to Invoices
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link
            to="/invoices"
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="h-6 w-6" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{invoice.invoiceNumber}</h1>
            <p className="text-sm text-gray-500">
              Created on {new Date(invoice.date).toLocaleDateString()}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={handlePrint}
            className="btn btn-secondary btn-md"
          >
            <Printer className="h-4 w-4 mr-2" />
            Print
          </button>
          <button
            onClick={handleSendEmail}
            className="btn btn-secondary btn-md"
          >
            <Mail className="h-4 w-4 mr-2" />
            Email
          </button>
          <button
            onClick={handleDownloadPDF}
            className="btn btn-secondary btn-md"
          >
            <Download className="h-4 w-4 mr-2" />
            Download PDF
          </button>
          <Link
            to={`/invoices/${id}/edit`}
            className="btn btn-primary btn-md"
          >
            <Edit className="h-4 w-4 mr-2" />
            Edit
          </Link>
        </div>
      </div>

      {/* Invoice Content */}
      <div className="card p-8 print:shadow-none">
        {/* Invoice Header */}
        <div className="flex justify-between items-start mb-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">INVOICE</h2>
            <p className="text-gray-600 mt-2">Invoice Management System</p>
          </div>
          <div className="text-right">
            <p className="text-lg font-semibold text-gray-900">{invoice.invoiceNumber}</p>
            <span className={`inline-flex px-3 py-1 text-sm font-semibold rounded-full ${getStatusColor(invoice.status)}`}>
              {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
            </span>
          </div>
        </div>

        {/* Customer & Invoice Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Bill To:</h3>
            <div className="text-gray-600">
              <p className="font-medium text-gray-900">{invoice.customer.name}</p>
              <p>{invoice.customer.email}</p>
              <p>{invoice.customer.phone}</p>
              {invoice.customer.address && (
                <p className="mt-2">{invoice.customer.address}</p>
              )}
              {invoice.customer.gstNumber && (
                <p className="mt-2">GST: {invoice.customer.gstNumber}</p>
              )}
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Invoice Details:</h3>
            <div className="text-gray-600 space-y-1">
              <p><span className="font-medium">Invoice Date:</span> {new Date(invoice.date).toLocaleDateString()}</p>
              <p><span className="font-medium">Due Date:</span> {new Date(invoice.dueDate).toLocaleDateString()}</p>
              <p><span className="font-medium">Status:</span> {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}</p>
            </div>
          </div>
        </div>

        {/* Items Table */}
        <div className="mb-8">
          <table className="w-full">
            <thead>
              <tr className="border-b-2 border-gray-200">
                <th className="text-left py-3 font-semibold text-gray-900">Item</th>
                <th className="text-center py-3 font-semibold text-gray-900">Qty</th>
                <th className="text-right py-3 font-semibold text-gray-900">Price</th>
                <th className="text-right py-3 font-semibold text-gray-900">Total</th>
              </tr>
            </thead>
            <tbody>
              {invoice.items.map((item, index) => (
                <tr key={index} className="border-b border-gray-100">
                  <td className="py-3 text-gray-900">{item.productName}</td>
                  <td className="py-3 text-center text-gray-600">{item.quantity}</td>
                  <td className="py-3 text-right text-gray-600">${item.price.toFixed(2)}</td>
                  <td className="py-3 text-right text-gray-900 font-medium">${item.total.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Totals */}
        <div className="flex justify-end">
          <div className="w-64">
            <div className="flex justify-between py-2">
              <span className="text-gray-600">Subtotal:</span>
              <span className="text-gray-900">${invoice.subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-gray-600">Tax:</span>
              <span className="text-gray-900">${invoice.tax.toFixed(2)}</span>
            </div>
            {invoice.discount > 0 && (
              <div className="flex justify-between py-2">
                <span className="text-gray-600">Discount:</span>
                <span className="text-gray-900">-${invoice.discount.toFixed(2)}</span>
              </div>
            )}
            <div className="border-t border-gray-200 pt-2">
              <div className="flex justify-between py-2">
                <span className="text-lg font-semibold text-gray-900">Total:</span>
                <span className="text-lg font-semibold text-gray-900">${invoice.total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Notes */}
        {invoice.notes && (
          <div className="mt-8 pt-8 border-t border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Notes:</h3>
            <p className="text-gray-600">{invoice.notes}</p>
          </div>
        )}

        {/* Footer */}
        <div className="mt-8 pt-8 border-t border-gray-200 text-center text-gray-500 text-sm">
          <p>Thank you for your business!</p>
        </div>
      </div>
    </div>
  );
}